export type Video = { id: string; title: string; description: string; thumbnail_url: string | null; duration_seconds: number; playback_id: string | null; asset_id: string | null; published: boolean; sort_order: number }
export type Progress = { watched_seconds: number; percent: number; status: 'unstarted' | 'in_progress' | 'completed'; completed_at: string | null }
