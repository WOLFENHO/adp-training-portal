import { NextResponse } from 'next/server'
import { z } from 'zod'
import { getMember } from '@/lib/auth'
import { adminDb } from '@/lib/supabase/admin'
import { mux } from '@/lib/mux'
import { randomUUID } from 'crypto'

async function authorize(){const m=await getMember();return m?.is_admin?m:null}
async function syncMuxUpload(uploadId:string){
 const upload=await mux.video.uploads.retrieve(uploadId)
 let ready=false
 if(upload.asset_id){
  const asset=await mux.video.assets.retrieve(upload.asset_id)
  ready=asset.status==='ready'
  const playback=asset.playback_ids?.find(p=>p.policy==='signed')
  const{data:video}=await adminDb.from('videos').select('id').eq('mux_upload_id',uploadId).maybeSingle()
  if(ready&&video&&playback?.id)await adminDb.from('videos').update({asset_id:asset.id,playback_id:playback.id,duration_seconds:Math.ceil(asset.duration||0)}).eq('id',video.id)
 }
 return {status:upload.status,assetId:upload.asset_id,ready}
}
export async function GET(request:Request){
 const admin=await authorize();if(!admin)return NextResponse.json({error:'forbidden'},{status:403})
 const uploadId=new URL(request.url).searchParams.get('uploadId')
 if(uploadId)return NextResponse.json(await syncMuxUpload(uploadId))
 const{data:pending}=await adminDb.from('videos').select('mux_upload_id').is('playback_id',null).not('mux_upload_id','is',null)
 await Promise.all((pending??[]).map(v=>v.mux_upload_id?syncMuxUpload(v.mux_upload_id):Promise.resolve(null)))
 const[{data:profiles},{data:allowed},{data:videos},{data:progress},{data:completions}]=await Promise.all([adminDb.from('profiles').select('*').order('username'),adminDb.from('authorized_discord_ids').select('*'),adminDb.from('videos').select('*').order('sort_order'),adminDb.from('user_video_progress').select('*'),adminDb.from('completion_records').select('user_id,video_id,completed_at,method')])
 return NextResponse.json({profiles:profiles??[],allowed:allowed??[],videos:videos??[],progress:progress??[],completions:completions??[],lastActivity:Object.fromEntries((profiles??[]).map(p=>[p.id,p.last_seen_at]))})
}
const schema=z.discriminatedUnion('action',[
 z.object({action:z.literal('access'),discordId:z.string().regex(/^\d{5,25}$/),enabled:z.boolean()}),
 z.object({action:z.literal('video-create'),title:z.string().min(1).max(180),description:z.string().max(4000).default('')}),
 z.object({action:z.literal('video-update'),videoId:z.string().uuid(),title:z.string().min(1).max(180),description:z.string().max(4000),thumbnailUrl:z.string().url().nullable().optional(),published:z.boolean(),sortOrder:z.number().int()}),
 z.object({action:z.literal('video-delete'),videoId:z.string().uuid()}),
 z.object({action:z.literal('progress-reset'),userId:z.string().uuid(),videoId:z.string().uuid()}),
 z.object({action:z.literal('progress-complete'),userId:z.string().uuid(),videoId:z.string().uuid()}),
])
export async function POST(request:Request){const member=await authorize();if(!member)return NextResponse.json({error:'forbidden'},{status:403});const parsed=schema.safeParse(await request.json().catch(()=>null));if(!parsed.success)return NextResponse.json({error:'invalid request',details:parsed.error.flatten()},{status:400});const x=parsed.data;let result:any={ok:true};
if(x.action==='access'){if(!x.enabled&&x.discordId===process.env.INITIAL_ADMIN_DISCORD_ID)return NextResponse.json({error:'The bootstrap administrator cannot be removed.'},{status:400});if(x.enabled){const{error}=await adminDb.from('authorized_discord_ids').upsert({discord_id:x.discordId,added_by:member.discord_id},{onConflict:'discord_id'});if(error)return NextResponse.json({error:error.message},{status:400})}else{await adminDb.from('authorized_discord_ids').delete().eq('discord_id',x.discordId)}result.discordId=x.discordId}
if(x.action==='video-create'){const videoId=randomUUID();const upload=await mux.video.uploads.create({cors_origin:process.env.NEXT_PUBLIC_APP_URL!,new_asset_settings:{playback_policies:['signed'],video_quality:'basic',passthrough:videoId}});const{error}=await adminDb.from('videos').insert({id:videoId,title:x.title,description:x.description,published:false,sort_order:999,mux_upload_id:upload.id,duration_seconds:0});if(error)return NextResponse.json({error:error.message},{status:400});result={ok:true,videoId,uploadId:upload.id,uploadUrl:upload.url}}
if(x.action==='video-update'){if(x.published){const{data:v}=await adminDb.from('videos').select('playback_id,duration_seconds').eq('id',x.videoId).maybeSingle();if(!v?.playback_id||!v.duration_seconds)return NextResponse.json({error:'Wait for Mux processing to finish before publishing.'},{status:400})}const{error}=await adminDb.from('videos').update({title:x.title,description:x.description,thumbnail_url:x.thumbnailUrl,published:x.published,sort_order:x.sortOrder}).eq('id',x.videoId);if(error)return NextResponse.json({error:error.message},{status:400})}
if(x.action==='video-delete'){const{data:v}=await adminDb.from('videos').select('asset_id').eq('id',x.videoId).maybeSingle();if(v?.asset_id)await mux.video.assets.delete(v.asset_id);await adminDb.from('videos').delete().eq('id',x.videoId)}
if(x.action==='progress-reset'){await adminDb.from('watched_intervals').delete().eq('user_id',x.userId).eq('video_id',x.videoId);await adminDb.from('user_video_progress').delete().eq('user_id',x.userId).eq('video_id',x.videoId);await adminDb.from('completion_records').delete().eq('user_id',x.userId).eq('video_id',x.videoId)}
if(x.action==='progress-complete'){const{data:v}=await adminDb.from('videos').select('duration_seconds').eq('id',x.videoId).single();if(!v||!v.duration_seconds)return NextResponse.json({error:'video not ready'},{status:400});const{error}=await adminDb.from('completion_records').upsert({user_id:x.userId,video_id:x.videoId,completed_at:new Date().toISOString(),method:'admin_override',admin_id:member.id},{onConflict:'user_id,video_id'});if(error)return NextResponse.json({error:error.message},{status:400});await adminDb.from('user_video_progress').upsert({user_id:x.userId,video_id:x.videoId,watched_seconds:v.duration_seconds,completed_at:new Date().toISOString(),updated_at:new Date().toISOString()},{onConflict:'user_id,video_id'})}
await adminDb.from('admin_audit_log').insert({admin_id:member.id,action:x.action,details:x});return NextResponse.json(result)}
