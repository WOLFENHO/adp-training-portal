import { NextResponse } from 'next/server'
import { z } from 'zod'
import { getMember } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'
const schema=z.object({sessionId:z.string().uuid(),position:z.number().finite().min(0),isPlaying:z.boolean()})
export async function POST(request:Request){const member=await getMember();if(!member)return NextResponse.json({error:'forbidden'},{status:403});const input=schema.safeParse(await request.json().catch(()=>null));if(!input.success)return NextResponse.json({error:'invalid heartbeat'},{status:400});const supabase=await createClient();const{data,error}=await supabase.rpc('record_playback_heartbeat',{p_session_id:input.data.sessionId,p_position:input.data.position,p_is_playing:input.data.isPlaying});if(error)return NextResponse.json({error:error.message},{status:422});return NextResponse.json(data)}
