import { NextResponse } from 'next/server'
import { getMember } from '@/lib/auth'
import { createClient } from '@/lib/supabase/server'
export async function POST(_:Request,{params}:{params:Promise<{id:string}>}){const member=await getMember();if(!member)return NextResponse.json({error:'forbidden'},{status:403});const{id}=await params;const supabase=await createClient();const{data,error}=await supabase.rpc('start_playback_session',{p_video_id:id});if(error)return NextResponse.json({error:'Could not start session'},{status:400});return NextResponse.json(data)}
